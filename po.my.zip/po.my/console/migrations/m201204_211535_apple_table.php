<?php

use common\components\MigrationX;

/**
 * Class m201204_211535_apple_table
 */
class m201204_211535_apple_table extends MigrationX
{
    /**
     * @inheritdoc
     * @throws Exception
     */
    public function safeUpX()
    {
        $this->createTableX('apple', 'Apples');
        $this->setTableCurrent('apple');
        $this->addColumnX('created', $this->timestamp(), 'Created');
        $this->addColumnX('color', $this->string(50), 'Color');
        $this->addColumnX('fallen', $this->timestamp(), 'Fallen moment');
        $this->addColumnX('status', $this->integer(1), 'Status');
        $this->addColumnX('eaten_percent', $this->integer(3), 'Eaten percent');
    }

    /**
     * @inheritdoc
     * @throws Exception
     */
    public function safeDown()
    {
        $this->dropTableX('apple');
    }
}
