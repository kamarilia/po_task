<?php
return [
    'class' => yii\db\Connection::class,
    'dsn' => 'mysql:host=127.0.0.1;dbname=po_test;port=8889',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];