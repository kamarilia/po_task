<?php

namespace common\components;

use Yii;
use yii\base\Exception;
use yii\db\ColumnSchemaBuilder;
use yii\db\Migration;
use yii\db\Schema;

/**
 * Class MigrationX
 * @package common\components
 */
class MigrationX extends Migration
{
    const OLD = '*old*';
    /**
     * @var null
     */
    protected $table_current = null;
    protected $news = [];
    protected $need_rollback = true;
    protected $after_adding_field = null;

    /**
     * @param bool $need_rollback
     */
    public function setNeedRollback(bool $need_rollback)
    {
        $this->need_rollback = $need_rollback;
    }

    public function setForeignKeyChecks(bool $status)
    {
        $this->execute('SET foreign_key_checks = ' . ($status ? '1' : '0') . ';');
    }

    /**
     * запоминает команды, чтобы корректно откатываться при сбое проведении миграции.
     * @param $type
     * @param string $action
     * @param $table
     * @param $name
     * @internal param array $news
     */
    protected function _addNews(string $action, $type, $table, $name, $new_name = '')
    {
        $this->news[] = [
            'action' => $action,
            'type' => $type,
            'table' => $table,
            'name' => $name,
            'new_name' => $new_name
        ];
    }

    protected function _addCreateNews($type, $table, $name, $new_name = '')
    {
        $this->_addNews('create', $type, $table, $name, $new_name);
    }

    protected function _rollback($last_error)
    {
        if (!$this->need_rollback || !$this->news) {
            return;
        }
        echo("\nMigration failed. Start a Rollback function.\n");
        if ($last_error) {
            $e = $last_error;
            /* @var $e \Exception */
            echo 'Exception: ' . $e->getMessage() . ' (' . $e->getFile() . ':' . $e->getLine() . ")\n";
            echo $e->getTraceAsString() . "\n";
            $m = method_exists($e, 'getMessage') ? $e->getMessage() : false;
            $name = method_exists($e, 'getName') ? $e->getName() : false;
            $code = method_exists($e, 'getCode') ? +$e->getCode() : false;
            if ($name === 'Database Exception'
                && $code === 42
                && strpos($m, 'Table') !== false
                && strpos($m, 'already exists') !== false
            ) {
                $table = explode(" Table '", $m);
                $table = explode("'", $table[1]);
                $news = [];
                foreach ($this->news as $new) {
                    if ($new['action'] === 'create'
                        && $new['type'] === 'table'
                        && $new['table'] === $table
                    ) {
                        continue;
                    }
                    $news[] = $new;
                }
                $this->news = $news;
            }
        }

        foreach (array_reverse($this->news) as $new) {
            $table = $new['table'];
            $action = $new['action'];
            $name = @$new['name'];
            $new_name = @$new['new_name'];
            switch ($action) {
                case 'create':
                    switch ($new['type']) {
                        case 'table':
                            $this->dropTable($table);
                            break;
                        case 'column':
                            $this->setTableCurrent($table);
                            $this->dropColumnX($name);
                            break;
                        case 'fk':
                            $this->dropForeignKey($name, $table);
                            break;
                        case 'index':
                            $this->dropIndex($name, $table);
                            break;
                        default:
                            throw new \Exception('Не поддерживаемый тип');
                    }
                    break;
                case 'drop':
                    switch ($new['type']) {
                        case 'table':
                            $this->createTableX($table, 'null');
                            break;
                        case 'column':
                            $this->setTableCurrent($table);
                            $this->addColumnX($name, $this->boolean(), 'null');
                            break;
                        default:
                            throw new \Exception('Не поддерживаемый тип');
                    }
                    break;
                case 'rename':
                    switch ($new['type']) {
                        case 'table':
                            $this->renameTable($new_name, $table);
                            break;
                        case 'column':
                            $this->renameColumnX($new_name, $name);
                            break;
                        default:
                            throw new \Exception('Не поддерживаемый тип');
                    }
                    break;
                default:
                    throw new \Exception('Не поддерживаемое действие');
            }
        }
    }

    /**
     * @return null
     * @throws \Exception
     */
    public function getTableCurrent()
    {
        if (!$t = $this->table_current) {
            throw new \Exception('Таблица не выбрана. Используйте setTableCurrent("table_name")');
        }
        return $t;
    }

    /**
     * @param string $table_current
     * @param null|string $after_adding_field
     * @return $this
     */
    public function setTableCurrent(string $table_current, $after_adding_field = null)
    {
        $this->table_current = $table_current;
        $this->after_adding_field = $after_adding_field;
        return $this;
    }

    /**
     * @param string $table
     * @param string $column
     * @param string $type
     * @param string $comment
     * @throws \Exception
     * @deprecated
     */
    public function addColumn($table, $column, $type, $comment = '')
    {
        parent::addColumn($table, $column, $type);
    }

    /**
     * добавление поля с проверкой обязательных полей: коммент, связанная таблица для полей вида *_id
     * @param string $column
     * @param $type
     * @param string $comment
     * @param string $after_field
     * @param bool $hidden
     * @param string $table4foreign_key
     * @param string $ref_columns
     * @param string $on_delete
     * @param string $on_update
     * @throws \Exception
     */
    public function addColumnX(
        string $column,
        $type,
        string $comment,
        $after_field = 'last',
        $hidden = false,
        $table4foreign_key = '',
        $ref_columns = 'id',
        $on_delete = 'SET NULL',
        $on_update = 'CASCADE'
    )
    {
        $table = $this->getTableCurrent();
        if (!$comment) {
            throw new \Exception('Нельзя создавать поля без комментария');
        }
        if (substr($column, -3) === '_id' && !$table4foreign_key) {
            throw new \Exception('Нельзя создавать колонки типа id без связи table_name [' . $table . '.' . $column . ']');
        }
        if ($after_field !== 'last') {
            $this->after_adding_field = $after_field;
        }
        if (null !== $this->after_adding_field) {
            $type .= ' AFTER ' . $this->after_adding_field;
        }
        parent::addColumn($table, $column, $type);
        $this->_addNews('create', 'column', $table, $column);
        $this->after_adding_field = $column;
        $this->setCommentOnColumnX($column, $comment, $hidden);
        if ($table4foreign_key) {
            $this->addForeignKeyX($column, $table4foreign_key, $ref_columns, $on_delete, $on_update);
        }
    }

    public function addColumnXSystemColumns()
    {
        $this->addColumnXSystemCreated();
    }

    public function addColumnXSystemCreated(
        $comment = 'Creation date',
        $hidden = true
    )
    {
        $type = 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP';
        $this->addColumnX('created', $type, $comment, 'last', $hidden);
    }

    /**
     * @inheritdoc
     * @param string $table
     * @param array $columns
     * @param null $options
     * @deprecated
     */
    public function createTable($table, $columns, $options = null)
    {
        parent::createTable($table, $columns, $options);
    }

    /**
     * создание таблицы с проверкой заполнения поля коммент
     * @param string $table
     * @param string $comment
     * @param string|null $options
     * @param bool $create_system_columns
     * @throws \Exception
     */
    public function createTableX(
        string $table,
        string $comment,
        $options = null
    )
    {
        if (!$comment) {
            throw new \Exception('Нельзя создавать таблицы без комментария');
        }
        $columns = ['id' => Schema::TYPE_PK];
        parent::createTable($table, $columns, $options);
        $this->_addNews('create', 'table', $table, false);
        $this->addCommentOnTable($table, $comment);

        $this->setTableCurrent('');
    }

    /**
     * @param string $name
     * @param string $table
     * @param array|string $columns
     * @param string $refTable
     * @param string $refColumns
     * @param string $delete
     * @param string $update
     */
    public function addForeignKey(
        $name,
        $table,
        $columns,
        $refTable,
        $refColumns = 'id',
        $delete = 'SET NULL',
        $update = 'CASCADE'
    )
    {
        parent::addForeignKey($name, $table, $columns, $refTable, $refColumns, $delete,
            $update);
        $this->_addNews('create', 'fk', $table, $name);
    }

    /**
     * добавление внешнего ключа с генерацией его имени
     * @param $columns
     * @param $ref_table
     * @param string $ref_columns
     * @param string $on_delete
     * @param string $on_update
     * @throws \Exception
     */
    public function addForeignKeyX(
        $columns,
        $ref_table,
        $ref_columns = 'id',
        $on_delete = 'SET NULL',
        $on_update = 'CASCADE'
    )
    {
        $table = $this->getTableCurrent();
        $this->dropForeignKeyByColumnX($columns);
        $name = 'fk_' . $this->_getKeyName($columns);
        $this->createIndexX($columns, false);
        parent::addForeignKey($name, $table, $columns, $ref_table, $ref_columns, $on_delete,
            $on_update);
        $this->_addNews('create', 'fk', $table, $name);
    }

    /* @deprecated */
    public function dropColumn($table, $column)
    {
        parent::dropColumn($table, $column);
    }

    /**
     * безопасное удаление колонки, если она имеет внешний ключ или индекс
     * @param string $column
     * @throws \Exception
     */
    public function dropColumnX(string $column)
    {
        $table = $this->getTableCurrent();
        $this->dropForeignKeyByColumnX($column);
        $this->dropIndexByColumnX($column);
        parent::dropColumn($table, $column);
        $this->_addNews('drop', 'column', $table, $column);
    }

    /**
     * @deprecated
     * @see setCommentOnColumn($table, $column, $comment)
     */
    public function addCommentOnColumn($table, $column, $comment)
    {
        parent::addCommentOnColumn($table, $column, $comment);
    }

    /**
     * @param $column
     * @param $comment
     * @param $hidden
     * @throws \Exception
     */
    public function setCommentOnColumnX($column, $comment, $hidden = false)
    {
        $hidden_postfix = '|hidden';
        $strlen_hidden_postfix = strlen($hidden_postfix);
        if ($hidden) {
            if (substr($comment, -$strlen_hidden_postfix) !== $hidden_postfix) {
                $comment .= $hidden_postfix;
            }
        } else {
            if (substr($comment, -$strlen_hidden_postfix) === $hidden_postfix) {
                $comment = substr($comment, 0, -$strlen_hidden_postfix);
            }
        }
        parent::addCommentOnColumn($this->getTableCurrent(), $column, $comment);
    }

    public function setCommentOnTableX(string $table, string $comment)
    {
        $this->dropCommentFromTable($table);
        $this->addCommentOnTable($table, $comment);
    }

    /**
     * @deprecated
     * @see renameColumnX($column, $comment)
     */
    public function renameColumn($table, $name, $newName)
    {
        parent::renameColumn($table, $name, $newName);
    }

    /**
     * @param $name
     * @param $newName
     * @throws \Exception
     */
    public function renameColumnX($name, $newName)
    {
        $table = $this->getTableCurrent();
        parent::renameColumn($table, $name, $newName);
        $this->_addNews('rename', 'column', $table, $name, $newName);
    }

    /**
     * @return bool|void
     * @throws \Throwable
     * @see safeUpX()
     * @deprecated
     */
    public function safeUp()
    {
        try {
            return $this->safeUpX();
        } catch (\Exception $e) {
            $this->_rollback($e);
            throw $e;
        } catch (\Throwable $e) {
            $this->_rollback($e);
            throw $e;
        }
    }

    public function safeUpX()
    {
        // write here new actions in Child Class
    }

    /**
     * изменение поля в таблице, self::OLD означает не менять это свойство
     * @param $column
     * @param string $type
     * @param string $allow_null
     * @param string $default_value
     * @param string $comment
     * @param string $after
     * @param string $hidden
     * @throws Exception
     * @throws \yii\base\NotSupportedException
     * @throws \Exception
     */
    public function setColumnParamsX(
        $column,
        $type = self::OLD,
        $allow_null = self::OLD,
        $default_value = self::OLD,
        $comment = self::OLD,
        $after = self::OLD,
        $hidden = self::OLD
    )
    {
        $table = $this->getTableCurrent();
        DbHelper::testExistsColumnInTable($table, $column);
        $tableSchema = \Yii::$app->db->schema->getTableSchema($table);
        if (!$tableSchema) {
            throw new \Exception('Не найдена схема для таблицы ' . $table);
        }
        $column_schema = $tableSchema->getColumn($column);
        if (!$column_schema) {
            throw new \Exception('Не найдена схема для колонки ' . $column . ' в таблице ' . $table);
        }
        $type__string = mb_strtolower((string)$type);
        if ($type === self::OLD) {
            $type__string = $column_schema->dbType;
        }
        if ($allow_null === self::OLD) {
            $allow_null__bool = $column_schema->allowNull;
        } else {
            $allow_null__bool = (bool)$allow_null;
        }
        $default_value_mixed = $default_value;
        if ($default_value === self::OLD) {
            $default_value_mixed = $column_schema->defaultValue;
            if ($type__string === 'bit' || $type__string === 'bit(1)') {
                $default_value_mixed = +$default_value_mixed;
            }
        }
        if ($column_schema->autoIncrement) {
            $type__string .= ' AUTO_INCREMENT';
        }
        $type_obj = $this->getDb()->getSchema()->createColumnSchemaBuilder($type__string)->defaultValue($default_value_mixed);
        if ($column === 'updated') {
            $type_obj->append('ON UPDATE CURRENT_TIMESTAMP');
        }
        if ($allow_null__bool) {
            $type_obj->null();
        } else {
            $type_obj->notNull();
        }
        if ($after !== self::OLD) {
            $type_obj->after($after);
        }
        $this->alterColumnX($column, $type_obj);
        if ($hidden === self::OLD) {
            $hidden = strpos($column_schema->comment, '|hidden') !== false;
        }
        if ($comment === self::OLD) {
            $comment = $column_schema->comment;
        }
        $this->setCommentOnColumnX($column, $comment, $hidden);
    }

    /**
     * @param string $table
     * @param string $column
     * @param string $type
     * @deprecated
     */
    public function alterColumn($table, $column, $type)
    {
        parent::alterColumn($table, $column, $type);
    }

    /**
     * @param $column
     * @param $type
     * @throws \Exception
     */
    public function alterColumnX($column, $type)
    {
        $table = $this->getTableCurrent();
        return parent::alterColumn($table, $column, $type);
    }

    /**
     * массовая замена типов полей во всех таблицах
     * @param $type_old
     * @param $type_new
     * @throws Exception
     * @throws \yii\base\NotSupportedException
     */
    public function changeFieldTypeInAllTables($type_old, $type_new)
    {
        $tables = \Yii::$app->db->schema->getTableNames();
        foreach ($tables as $table) {
            if (DbHelper::isView($table)) {
                continue;
            }
            $table_obj = Yii::$app->db->schema->getTableSchema($table);
            if (!$table_obj) {
                continue;
            }
            foreach ($table_obj->columns as $column) {
                if ($column->dbType !== $type_old) {
                    continue;
                }
                $this->setTableCurrent($table_obj->name);
                $this->setColumnParamsX($column->name, $type_new);

            }
        }
    }

    /**
     * @param string $table
     * @deprecated
     */
    public function dropTable($table)
    {
        parent::dropTable($table);
    }

    /**
     * @param string $table
     */
    public function dropTableX(string $table)
    {
        parent::dropTable($table);
        $this->_addNews('drop', 'table', $table, false);
    }

    /**
     * @param string $table
     * @param string $newName
     * @deprecated
     */
    public function renameTable($table, $newName)
    {
        parent::renameTable($table, $newName);
    }

    /**
     * @param string $table
     * @param string $newName
     */
    public function renameTableX(string $table, string $newName): void
    {
        parent::renameTable($table, $newName);
        $this->_addNews('rename', 'table', $table, '', $newName);
    }


    /*************** TYPES ****************/

    /**
     * @param int|null $length
     * @return ColumnSchemaBuilder
     */
    public function string($length = 255)
    {
        return parent::string($length);
    }

    /**
     * @param int|null $length
     * @return ColumnSchemaBuilder
     */
    public function integer($length = 11)
    {
        return parent::integer($length);
    }

    /**
     * @param int|null $precision
     * @param int|null $scale
     * @return ColumnSchemaBuilder
     */
    public function decimal($precision = 12, $scale = 4)
    {
        return parent::decimal($precision, $scale);
    }


    /**
     * @throws Exception
     */
    public function executeByClassSqlFile()
    {
        return $this->_exec_sql_file(Yii::getAlias('@console') . '/migrations/_sql_up/' . static::class . '.sql');
    }

    /**
     * Получает id последней вставленной записи
     * @return string
     */
    public function getLastInsertId()
    {
        return $this->getDb()->getLastInsertId();
    }
}