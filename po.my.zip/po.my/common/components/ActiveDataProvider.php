<?php
/**
 * Created by PhpStorm.
 * User: dalph
 * Date: 17.08.2018
 * Time: 09:42
 */

namespace common\components;

use yii\data\ActiveDataProvider as YiiActiveDataProvider;

class ActiveDataProvider extends YiiActiveDataProvider
{
    public function offPagination()
    {
        $this->setPagination(['pageSize' => 0]);
    }
}