<?php
namespace backend\controllers;

use backend\models\Account;
use backend\models\Apple;
use backend\widgets\Tabs;
use yii\db\Expression;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use Yii;
use Exception;
use common\components\ActiveDataProvider;

/**
 * Apple controller
 */
class AppleController extends Controller
{
    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        // будем проверять только лежащие на земле негнилые яблоки
        $good_apples_on_the_ground = Apple::find()->andWhere(['status' => 1])->all();

        foreach ($good_apples_on_the_ground as $apple) {
            $time_gap = round((time() - strtotime($apple->fallen))/3600 * 60, 1);

            // если яблоко полежало 15 мин - оно портится
            if ($time_gap >= 15) {
                $apple->status = 2; // гнилое
                $apple->save();
            }
        }

        $dataProvider = new ActiveDataProvider([
            'query' => Apple::find()->andWhere(['<>', 'status', 3]),
        ]);

        return $this->render('index', [
            'dataProvider' => $dataProvider
        ]);
    }

    /*
     * Сгенерировать новые яблоки в случайном кол-ве от 10 до 30 случайного цвета
     * return $status string
     */
    public function actionGenerateApples()
    {
        if (!Yii::$app->request->isAjax) {
            throw new NotFoundHttpException();
        }
        Yii::$app->response->format = Response::FORMAT_JSON;

        try {
            // Удяляем все старые яблоки
            Apple::deleteAll();

            // создаем яблоки в случайном кол-ве >= 10 и <= 30
            $random_quantity = rand(10, 30);

            for ($i = 0; $i < $random_quantity; $i++) {
                // случайная метка времени в прошлом в диапазоне сегодня минус 30 дней
                $past_date_random = mktime(0, 0, 0, date('n'), date('d') - rand(0, 30),
                    date('Y'));

                // случайный цвет из 3-х возможных
                $colors = ['green', 'red', 'gold'];
                $color = $colors[rand(0, 2)];

                $apple = new Apple();
                $apple->created = date('Y-m-d', $past_date_random);
                $apple->color = $color;
                $apple->status = 0;
                $apple->save();
            }

            return ['status' => 'OK', 'random_quantity' => $random_quantity];
        } catch (Exception $e) {
            return ['status' => 'ERROR', 'message' => $e->getMessage()];
        }
    }

    /*
     * Упасть
     * return $status string
     */
    public function actionFall()
    {
        if (!Yii::$app->request->isAjax) {
            throw new NotFoundHttpException();
        }
        Yii::$app->response->format = Response::FORMAT_JSON;

        try {
            $id = Yii::$app->request->post('id');

            // Ищем яблоко по id
            $apple = Apple::findOne($id);

            if ($apple) {
                $apple->fallen = new Expression('NOW()');
                $apple->status = 1; // упало
                $apple->save();
            }

            return ['status' => 'OK'];
        } catch (Exception $e) {
            return ['status' => 'ERROR', 'message' => $e->getMessage()];
        }
    }

    /*
     * Есть яблоко - за раз можно откусить на 25%
     * return $status string
     */
    public function actionEat()
    {
        if (!Yii::$app->request->isAjax) {
            throw new NotFoundHttpException();
        }
        Yii::$app->response->format = Response::FORMAT_JSON;

        try {
            $status = 'Действие не определено';
            $id = Yii::$app->request->post('id');

            // Ищем яблоко по id
            $apple = Apple::findOne($id);

            if ($apple) {
                // Проверяем, когда упало
                $time_gap = round((time() - strtotime($apple->fallen))/3600 * 60, 1);

                // если яблоко висит - съесть нельзя
                if ($apple->status === 0) {

                    $status = 'Съесть нельзя, яблоко на дереве';

                    return ['status' => $status];
                } elseif ($time_gap >= 15) { // если яблоко полежало 15 мин - оно портится
                    $apple->status = 2; // гнилое
                    $apple->save();

                    $status = 'Яблоко гнилое - не ешьте его!';

                    return ['status' => $status];
                }

                // яблоко откусывается за раз на 25%
                $apple->eaten_percent += 25;

                if ($apple->eaten_percent === 100) {
                    $apple->status = 3; // съедено
                }

                $apple->save();
            }

            if ($apple->status === 1) {
                $status = 'Откушено на ' . $apple->eaten_percent . '%';
            } elseif ($apple->status === 3) {
                $status = 'Съедено';
            }

            return ['status' => $status];
        } catch (Exception $e) {
            return ['status' => 'ERROR', 'message' => $e->getMessage()];
        }
    }

}
