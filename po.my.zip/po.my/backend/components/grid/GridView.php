<?php

namespace backend\components\grid;

use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\helpers\Json;

class GridView extends \yii\grid\GridView
{
    public $headerHtml;
    public $tableOptions = ['class' => 'x_panel table table-hover'];

    /**
     * Runs the widget.
     */
    public function run()
    {
        $id = $this->options['id'];
        $options = Json::htmlEncode($this->getClientOptions());
        $view = $this->getView();
        GridViewAsset::register($view);
        $view->registerJs("jQuery('#$id').yiiGridView($options);");

        if ($this->showOnEmpty || $this->dataProvider->getCount() > 0) {
            $content = preg_replace_callback("/{\\w+}/", function ($matches) {
                $content = $this->renderSection($matches[0]);

                return $content === false ? $matches[0] : $content;
            }, $this->layout);
        } else {
            $content = $this->renderEmpty();
        }

        $options = $this->options;
        $tag = ArrayHelper::remove($options, 'tag', 'div');
        echo Html::tag($tag, $content, $options);

        $tr_onclick_js = <<<JS
$(function() {
  $('.table__tr_onclick2item tbody tr').on('click', function(event) {
    var srcElement = event.originalEvent.target;
    var tagName = srcElement.tagName;
  
    // console.log('table__tr_onclick2item clicked by ' + tagName);
    if (['TD','TR'].indexOf(tagName) === -1) {
      return true;
    }
    let doc_id = $(this).data('key');
    if (!doc_id) return false;
    
    let pathname = $(this).closest('table').data('onclick2item-url');
    let tableAttr = $(this).closest('table').data('link');
  
    if (!pathname){
        pathname = window.location.pathname;
        if (pathname.substr(-6) === '/index') pathname = pathname.substr(0,pathname.length-6);
        if (pathname.substr(-1) === '/') pathname = pathname.substr(0,pathname.length-1);
    }
    // window.location.href = pathname +'/update?'+$.param({id: doc_id});
    //  window.location.href =  '/'+ tableAttr +'/update?'+$.param({id: doc_id});
    //  window.location.href = '../';
    window.location.href = (tableAttr ? '/' + tableAttr : pathname)+'/update?'+$.param({id: doc_id});
  });
  
  /* $('.table__tr_onclick2item tbody td > a').on('click',function (event) {
    let access_action = $(this).attr('href').indexOf('#') > -1;
    if (!access_action){
      console.log('action was locked by GridView js');
      return false;
    }
  }); */
});
JS;
        $this->view->registerJs($tr_onclick_js, $this->view::POS_END, 'tr_onclick_js');
    }

    public function renderTableHeader()
    {
        return $this->headerHtml ?: parent::renderTableHeader();
    }

}