<?php

namespace backend\components\grid;

class GridViewKartik extends \kartik\grid\GridView
{
    public $tableOptions = ['class' => 'x_panel table table-hover'];
    public $bordered = false;
    public $striped = false;
}