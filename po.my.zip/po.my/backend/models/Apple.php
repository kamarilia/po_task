<?php

namespace backend\models;

use yii\helpers\Html;

/**
 * This is the model class for table "apple".
 *
 * @property int $id
 * @property string|null $created Создано
 * @property string|null $color Цвет
 * @property string|null $fallen Когда упало
 * @property int|null $status Статус
 * @property int|null $eaten_percent Процент съеденого
 */
class Apple extends \yii\db\ActiveRecord
{
    protected static $gridColumns = ['_serial', 'id', 'color', 'status'];

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'apple';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['created', 'fallen'], 'safe'],
            [['status', 'eaten_percent'], 'integer'],
            [['color'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'created' => 'Created',
            'color' => 'Color',
            'fallen' => 'Fallen',
            'status' => 'Status',
            'eaten_percent' => 'Eaten Percent',
        ];
    }

    public static function getGridColumnsFull()
    {
        $gridColumns = [
            ['class' => 'yii\grid\SerialColumn'],
            'color' => [
                'attribute' => 'color',
                'header' => 'Яблоко',
                'content' => function ($model) {
                    $apple_class = $model->eaten_percent ? 'fab fa-apple' : 'fas fa-apple-alt';
                    $apple_icon = "<i style='color: {$model->color}; font-size: 2em; margin-right: 20px' class='{$apple_class}'></i>";

                    return $apple_icon;
                },
            ],
            'size' => [
                'attribute' => 'eaten_percent',
                'header' => 'Размер',
                'content' => function ($model) {
                    $apple_size = (100 - $model->eaten_percent) / 100;

                    return $apple_size;
                },
            ],
            'status' => [
                'attribute' => 'status',
                'header' => 'Состояние',
                'content' => function ($model) {
                    $apple_status = '';

                    if ($model->status === 0) {
                        $apple_status = 'Висит';
                    } elseif ($model->status === 1) {
                        $apple_status = 'Лежит на земле';
                    } elseif ($model->status === 2) {
                        $apple_status = 'Гнилое';
                    }

                    return $apple_status;
                },
            ],
            'actions' => [
                'attribute' => 'status',
                'header' => 'Действия',
                'content' => function ($model) {
                    $actions = '';

                    if ($model->status === 0) {
                        $actions = Html::button('<i class="fas fa-arrow-down"></i>', ['id' => 'fall', 'data-id' => $model->id])
                            . Html::button('<i class="fas fa-teeth-open"></i>', ['id' => 'eat', 'data-id' => $model->id]);
                    } elseif ($model->status === 1) {
                        $actions = Html::button('<i class="fas fa-teeth-open"></i>', ['id' => 'eat', 'data-id' => $model->id]);;
                    }

                    return $actions;
                },
            ],
        ];

        return $gridColumns;
    }
}
