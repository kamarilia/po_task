<?php
namespace backend\widgets;

use yii\web\Response;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use Yii;

class Pjax extends \yii\widgets\Pjax {

    /**
     * @inheritdoc
     */
    public function run()
    {
        $view = $this->getView();
        $view->registerJs("if ($('.select2').data('select2')) { $('.select2').select2('destroy'); }", \yii\web\View::POS_END);
        if (!$this->requiresPjax()) {
            echo Html::endTag(ArrayHelper::remove($this->options, 'tag', 'div'));
            $this->registerClientScript();

            return;
        }

        $view->endBody();

        // Do not re-send css files as it may override the css files that were loaded after them.
        // This is a temporary fix for https://github.com/yiisoft/yii2/issues/2310
        // It should be removed once pjax supports loading only missing css files
        //$view->cssFiles = null;


        $view->endPage(true);

        $content = ob_get_clean();

        // only need the content enclosed within this widget
        $response = Yii::$app->getResponse();
        $response->clearOutputBuffers();
        $response->setStatusCode(200);
        $response->format = Response::FORMAT_HTML;
        $response->content = $content;
        $response->headers->setDefault('X-Pjax-Url', Yii::$app->request->url);
        $response->send();
        exit();
    }
}