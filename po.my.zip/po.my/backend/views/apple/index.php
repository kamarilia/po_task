<?php

use yii\helpers\Html;
use backend\widgets\Pjax;
use backend\models\Apple;
use backend\components\grid\GridView;

$this->title = 'Яблоки';

$btn_title = count($dataProvider->getModels()) ? 'Сгенерировать другие яблоки' : 'Сгенерировать яблоки';
echo Html::button($btn_title, ['class' => 'btn btn-primary', 'id' => 'generate-apples']);
?>
<br /><br />
<?php
Pjax::begin([
    'id' => 'main-pjax-container',
    'timeout' => 0,
]);

echo GridView::widget([
    'dataProvider' => $dataProvider,
    'pager' => [
        'class' => yii\widgets\LinkPager::class,
        'firstPageLabel' => 'Первая',
        'lastPageLabel' => 'Последняя',
    ],
    'tableOptions' => ['class' => 'x_panel table table-hover table__tr_onclick2item'],
    'headerRowOptions' => ['class' => 'x'],
    'columns' => Apple::getGridColumnsFull()
]);

Pjax::end();

$js = <<<JS
$(function(){
    // Генерируем случайное кол-во яблок
   $(document).on('click', '#generate-apples', function() {
       $.post('/apple/generate-apples', '', function(response) {
           alert('Сгенерировано ' + response.random_quantity + ' новых яблок!');
           $.pjax.reload({container: '#main-pjax-container', timeout: 0});
       });
   }); 
   
   // Яблоко падает
   $(document).on('click', '#fall', function() {
       let data = {
           id: $(this).attr('data-id')
       };
       
       $.post('/apple/fall', data, function(response) {
           alert('Упало');
           $.pjax.reload({container: '#main-pjax-container', timeout: 0});
       });
   }); 
   
   // Съесть
   $(document).on('click', '#eat', function() {
       let data = {
           id: $(this).attr('data-id')
       };
       
       $.post('/apple/eat', data, function(response) {
           alert(response.status);
           $.pjax.reload({container: '#main-pjax-container', timeout: 0});
       });
   }); 
});
JS;
$this->registerJs($js);
// подключаю иконки
$this->registerJsFile('https://kit.fontawesome.com/72956d55a6.js', ['crossorigin' => 'anonymous']);